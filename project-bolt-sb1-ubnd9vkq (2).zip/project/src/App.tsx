import React, { useState, useEffect, useRef } from 'react';
import { 
  Flame, 
  Smartphone, 
  Users, 
  Clock, 
  Shield, 
  DollarSign, 
  CheckCircle, 
  Monitor, 
  UtensilsCrossed, 
  MapPin, 
  Receipt, 
  CreditCard, 
  ChefHat, 
  Package, 
  QrCode, 
  BarChart3, 
  UserCheck, 
  FileText,
  Phone,
  MessageCircle,
  Mail,
  ChevronDown,
  Star,
  ArrowRight,
  Play,
  Home,
  ShoppingCart,
  Layout,
  Wallet,
  FileBarChart,
  Bell,
  Truck,
  Store,
  Warehouse,
  TrendingUp,
  PieChart,
  Calendar,
  Target,
  Settings,
  Database,
  Utensils,
  Coffee,
  Wine,
  Soup,
  Cookie,
  Pizza,
  IceCream,
  Beef,
  Fish,
  Salad,
  Cake,
  Apple,
  Grape,
  Cherry,
  Croissant,
  Zap,
  Layers,
  Globe,
  Headphones,
  Award,
  Sparkles,
  Rocket,
  Heart,
  Eye,
  Cpu,
  Wifi,
  Lock,
  Search,
  Filter,
  Grid3X3
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeFeature, setActiveFeature] = useState(0);
  const [visibleElements, setVisibleElements] = useState(new Set());
  const [selectedCategory, setSelectedCategory] = useState('Tümü');

  // Intersection Observer for scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleElements(prev => new Set([...prev, entry.target.id]));
          }
        });
      },
      { threshold: 0.1, rootMargin: '50px' }
    );

    // Observe all animated elements
    const elements = document.querySelectorAll('[data-animate]');
    elements.forEach(el => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  // Smooth scroll effect
  useEffect(() => {
    const handleScroll = () => {
      const navbar = document.getElementById('navbar');
      if (navbar) {
        if (window.scrollY > 100) {
          navbar.classList.add('backdrop-blur-lg', 'bg-amber-900/90');
        } else {
          navbar.classList.remove('backdrop-blur-lg', 'bg-amber-900/90');
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-rotate features
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % allFeatures.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const allFeatures = [
    { icon: Home, title: 'Ana Sayfa', desc: 'Merkezi kontrol paneli', color: 'from-orange-500 to-red-600', category: 'Temel' },
    { icon: ShoppingCart, title: 'Sipariş', desc: 'Hızlı sipariş alma sistemi', color: 'from-amber-500 to-orange-600', category: 'Satış' },
    { icon: Layout, title: 'Açık Masalar', desc: 'Masa durumu takibi', color: 'from-yellow-500 to-amber-600', category: 'Masa' },
    { icon: MapPin, title: 'Açık Masalar Kroki-1', desc: 'Görsel masa düzeni', color: 'from-lime-500 to-yellow-600', category: 'Masa' },
    { icon: Wallet, title: 'Ödeme Al', desc: 'Hızlı ödeme işlemleri', color: 'from-green-500 to-lime-600', category: 'Ödeme' },
    { icon: Clock, title: 'Ödeme Geçmişi', desc: 'Ödeme kayıtları', color: 'from-emerald-500 to-green-600', category: 'Ödeme' },
    { icon: FileBarChart, title: 'Fiş Yazdırmalar', desc: 'Fiş ve fatura yazdırma', color: 'from-teal-500 to-emerald-600', category: 'Yazdırma' },
    { icon: Bell, title: 'Bildirimler', desc: 'Anlık bildirim sistemi', color: 'from-cyan-500 to-teal-600', category: 'Sistem' },
    { icon: Receipt, title: 'Sipariş Bildirimleri', desc: 'Sipariş durum bildirimleri', color: 'from-sky-500 to-cyan-600', category: 'Bildirim' },
    { icon: Truck, title: 'Vale', desc: 'Vale hizmet yönetimi', color: 'from-blue-500 to-sky-600', category: 'Hizmet' },
    { icon: Store, title: 'Hammadde Depo Stok', desc: 'Hammadde stok takibi', color: 'from-indigo-500 to-blue-600', category: 'Stok' },
    { icon: Warehouse, title: 'Üretim Depo Stok', desc: 'Üretim stok yönetimi', color: 'from-purple-500 to-indigo-600', category: 'Stok' },
    { icon: TrendingUp, title: 'Raporlar', desc: 'Detaylı analiz raporları', color: 'from-violet-500 to-purple-600', category: 'Rapor' },
    { icon: BarChart3, title: 'Satış Hareketleri', desc: 'Satış analizi', color: 'from-fuchsia-500 to-violet-600', category: 'Rapor' },
    { icon: PieChart, title: 'Satış Raporları', desc: 'Satış performans raporları', color: 'from-pink-500 to-fuchsia-600', category: 'Rapor' },
    { icon: Target, title: 'Cari Hesap Hareketleri', desc: 'Müşteri hesap takibi', color: 'from-rose-500 to-pink-600', category: 'Finans' },
    { icon: Calendar, title: 'Satın Alma Raporu', desc: 'Satın alma analizi', color: 'from-red-500 to-rose-600', category: 'Rapor' },
    { icon: Users, title: 'Personel KPI Raporu', desc: 'Personel performans takibi', color: 'from-orange-600 to-red-600', category: 'İnsan Kaynakları' },
    { icon: FileText, title: 'Karlılık Raporu', desc: 'Karlılık analizi', color: 'from-amber-600 to-orange-600', category: 'Finans' },
    { icon: TrendingUp, title: 'Ürün Fiyat Raporu', desc: 'Fiyat analiz raporu', color: 'from-yellow-600 to-amber-600', category: 'Fiyat' },
    { icon: Calendar, title: 'Rezervasyon Raporu', desc: 'Rezervasyon istatistikleri', color: 'from-lime-600 to-yellow-600', category: 'Rezervasyon' },
    { icon: Database, title: 'Stok Raporu', desc: 'Stok durum raporu', color: 'from-green-600 to-lime-600', category: 'Stok' },
    { icon: Package, title: 'Tüketim Stok Raporu', desc: 'Tüketim analizi', color: 'from-emerald-600 to-green-600', category: 'Stok' },
    { icon: Warehouse, title: 'Stok Sayım Raporu', desc: 'Stok sayım takibi', color: 'from-teal-600 to-emerald-600', category: 'Stok' },
    { icon: Receipt, title: 'Acil Sipariş Raporu', desc: 'Acil sipariş takibi', color: 'from-cyan-600 to-teal-600', category: 'Sipariş' },
    { icon: Settings, title: 'Yönetici Özet Raporu', desc: 'Yönetici dashboard', color: 'from-sky-600 to-cyan-600', category: 'Yönetim' },
    { icon: FileText, title: 'Zayi Raporu', desc: 'Fire ve zayi takibi', color: 'from-blue-600 to-sky-600', category: 'Rapor' },
    { icon: Coffee, title: 'Yemek Hazırlama Raporu', desc: 'Mutfak hazırlık raporu', color: 'from-indigo-600 to-blue-600', category: 'Mutfak' },
    { icon: BarChart3, title: 'Veri Giriş Raporu', desc: 'Veri giriş analizi', color: 'from-purple-600 to-indigo-600', category: 'Veri' },
    { icon: PieChart, title: 'Anket Sonuçları', desc: 'Müşteri memnuniyet anketi', color: 'from-violet-600 to-purple-600', category: 'Müşteri' },
    { icon: Users, title: 'Müşteri/Cari Yönetimi', desc: 'Müşteri ilişkileri yönetimi', color: 'from-fuchsia-600 to-violet-600', category: 'CRM' },
    { icon: Utensils, title: 'Menü', desc: 'Menü yönetim sistemi', color: 'from-pink-600 to-fuchsia-600', category: 'Menü' },
    { icon: Settings, title: 'Menü Dil Opsiyonları', desc: 'Çoklu dil desteği', color: 'from-rose-600 to-pink-600', category: 'Menü' },
    { icon: Coffee, title: 'Menü Kategorisi', desc: 'Kategori yönetimi', color: 'from-red-600 to-rose-600', category: 'Menü' },
    { icon: Pizza, title: 'Menü Üst Kategorisi', desc: 'Ana kategori düzenleme', color: 'from-orange-700 to-red-600', category: 'Menü' },
    { icon: Soup, title: 'Opsiyonlar', desc: 'Ürün seçenekleri', color: 'from-amber-700 to-orange-600', category: 'Menü' },
    { icon: Wine, title: 'Tadım Menüleri', desc: 'Özel tadım menüleri', color: 'from-yellow-700 to-amber-600', category: 'Menü' },
    { icon: Cake, title: 'Özel Kategoriler', desc: 'Özel kategori tanımları', color: 'from-lime-700 to-yellow-600', category: 'Menü' },
    { icon: Settings, title: 'Ayarlar', desc: 'Sistem ayarları', color: 'from-green-700 to-lime-600', category: 'Sistem' },
    { icon: Layout, title: 'Restoran Masa Düzeni', desc: 'Masa düzeni tasarımı', color: 'from-emerald-700 to-green-600', category: 'Masa' },
    { icon: ChefHat, title: 'Mutfak Bölümleri', desc: 'Mutfak alan yönetimi', color: 'from-teal-700 to-emerald-600', category: 'Mutfak' },
    { icon: Users, title: 'Grup Hesap Yönetimi', desc: 'Grup hesap işlemleri', color: 'from-cyan-700 to-teal-600', category: 'Hesap' },
    { icon: UserCheck, title: 'Kullanıcı Rolleri', desc: 'Yetki yönetimi', color: 'from-sky-700 to-cyan-600', category: 'Yetki' },
    { icon: Database, title: 'Kullanıcı Listesi', desc: 'Kullanıcı yönetimi', color: 'from-blue-700 to-sky-600', category: 'Kullanıcı' },
    { icon: Receipt, title: 'Anket Soruları', desc: 'Anket yönetimi', color: 'from-indigo-700 to-blue-600', category: 'Anket' },
    { icon: Calendar, title: 'Özel Gün Ekle', desc: 'Özel gün tanımları', color: 'from-purple-700 to-indigo-600', category: 'Takvim' },
    { icon: Calendar, title: 'Rezervasyon Durumu', desc: 'Rezervasyon takibi', color: 'from-violet-700 to-purple-600', category: 'Rezervasyon' },
    { icon: FileText, title: 'Rezervasyon Raporlar', desc: 'Rezervasyon raporları', color: 'from-fuchsia-700 to-violet-600', category: 'Rezervasyon' },
    { icon: Package, title: 'Çıkış', desc: 'Güvenli çıkış', color: 'from-pink-700 to-fuchsia-600', category: 'Sistem' },
    { icon: Smartphone, title: 'Müşteriye Özel App', desc: 'Mobil uygulama', color: 'from-rose-700 to-pink-600', category: 'Mobil' },
    { icon: Monitor, title: 'Müşteriye Özel Web Domain', desc: 'Özel web sitesi', color: 'from-red-700 to-rose-600', category: 'Web' },
    { icon: Phone, title: 'Garson App', desc: 'Garson mobil uygulaması', color: 'from-orange-800 to-red-700', category: 'Mobil' },
    { icon: Truck, title: 'Pazaryeri Bağlantısı', desc: 'Online pazaryeri entegrasyonu', color: 'from-amber-800 to-orange-700', category: 'Entegrasyon' },
    { icon: Store, title: 'Çoklu Şube Yönetimi', desc: 'Çoklu şube kontrolü', color: 'from-yellow-800 to-amber-700', category: 'Şube' },
    { icon: Smartphone, title: 'Mobilden Ödeme', desc: 'Mobil ödeme sistemi', color: 'from-lime-800 to-yellow-700', category: 'Ödeme' },
    { icon: MessageCircle, title: 'Mesaj Yönetimi (SMS Paketi İsteğe Bağlı)', desc: 'SMS bildirim sistemi', color: 'from-green-800 to-lime-700', category: 'İletişim' }
  ];

  const categories = ['Tümü', ...new Set(allFeatures.map(f => f.category))];

  const filteredFeatures = selectedCategory === 'Tümü' 
    ? allFeatures 
    : allFeatures.filter(f => f.category === selectedCategory);

  const packages = [
    {
      id: 'lite',
      name: 'Lite',
      color: 'from-amber-500 via-orange-500 to-red-500',
      features: ['Temel Masa Yönetimi', 'Sipariş Alma', 'Basit Raporlama', '1 Kullanıcı', 'Telefon Desteği'],
      icon: Coffee
    },
    {
      id: 'prime',
      name: 'Prime',
      color: 'from-orange-500 via-red-500 to-pink-500',
      popular: true,
      features: ['Tüm Lite Özellikler', 'QR Menü', 'Mutfak Ekranı', '5 Kullanıcı', 'Gelişmiş Raporlar', 'WhatsApp Desteği'],
      icon: Rocket
    },
    {
      id: 'master',
      name: 'Master',
      color: 'from-red-500 via-pink-500 to-purple-500',
      features: ['Tüm Prime Özellikler', 'Çoklu Şube', 'API Entegrasyonu', 'Sınırsız Kullanıcı', 'Özel Eğitim', '7/24 Destek'],
      icon: Award
    }
  ];

  const testimonials = [
    { name: 'Mehmet Yılmaz', business: 'Lezzet Durağı', rating: 5, text: 'Blaze sayesinde işlerimiz çok kolaylaştı. Özellikle masa yönetimi harika!' },
    { name: 'Ayşe Kaya', business: 'Boğaz Cafe', rating: 5, text: 'QR menü özelliği müşterilerimiz tarafından çok beğenildi. Kesinlikle tavsiye ederim.' },
    { name: 'Ali Demir', business: 'Şehir Lokantası', rating: 5, text: 'Raporlama sistemi sayesinde işletmemizin performansını çok daha iyi takip ediyoruz.' }
  ];

  const faqs = [
    {
      q: 'Blaze sadece restoranlarda mı kullanılır?',
      a: 'Hayır, kafe, pastane, lokanta, fast food ve büfe gibi birçok işletme için uygundur.'
    },
    {
      q: 'Kurulum süreci ne kadar sürüyor?',
      a: 'Kurulum ve eğitim süreci aynı gün içinde tamamlanabilir.'
    },
    {
      q: 'Destek hizmeti veriyor musunuz?',
      a: 'Evet. Telefon, WhatsApp ve uzaktan bağlantı ile destek sağlıyoruz.'
    },
    {
      q: 'Paketler arasında geçiş yapabilir miyim?',
      a: 'Elbette. İşletmenizin ihtiyacına göre üst pakete geçiş yapabilirsiniz.'
    },
    {
      q: 'Yedekleme yapılıyor mu?',
      a: 'Evet. Tüm veriler günlük olarak yedeklenir.'
    }
  ];

  const advantages = [
    {
      icon: Zap,
      title: 'Yıldırım Hızı',
      desc: 'Saniyeler içinde sipariş alma ve işleme',
      color: 'from-yellow-400 via-orange-500 to-red-500'
    },
    {
      icon: Layers,
      title: 'Modüler Yapı',
      desc: 'İhtiyacınıza göre büyüyen sistem',
      color: 'from-blue-400 via-purple-500 to-pink-500'
    },
    {
      icon: Globe,
      title: 'Her Yerden Erişim',
      desc: 'Bulut tabanlı, her cihazdan kullanım',
      color: 'from-green-400 via-teal-500 to-blue-500'
    },
    {
      icon: Headphones,
      title: '7/24 Destek',
      desc: 'Kesintisiz teknik destek hizmeti',
      color: 'from-purple-400 via-pink-500 to-red-500'
    },
    {
      icon: Lock,
      title: 'Güvenli Altyapı',
      desc: 'Bankacılık seviyesinde güvenlik',
      color: 'from-indigo-400 via-blue-500 to-cyan-500'
    },
    {
      icon: Cpu,
      title: 'AI Destekli',
      desc: 'Yapay zeka ile akıllı öneriler',
      color: 'from-pink-400 via-rose-500 to-orange-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50 text-slate-800 overflow-x-hidden">
      {/* Navigation */}
      <nav id="navbar" className="fixed top-0 w-full z-50 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <Flame className="h-8 w-8 text-orange-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                Blaze
              </span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('features')} className="hover:text-orange-600 transition-colors font-medium">
                Özellikler
              </button>
              <button onClick={() => scrollToSection('advantages')} className="hover:text-orange-600 transition-colors font-medium">
                Avantajlar
              </button>
              <button onClick={() => scrollToSection('packages')} className="hover:text-orange-600 transition-colors font-medium">
                Paketler
              </button>
              <button onClick={() => scrollToSection('references')} className="hover:text-orange-600 transition-colors font-medium">
                Referanslar
              </button>
              <button onClick={() => scrollToSection('contact')} className="bg-gradient-to-r from-orange-500 to-red-600 text-white px-6 py-2 rounded-full hover:from-orange-600 hover:to-red-700 transition-all transform hover:scale-105 shadow-lg">
                Demo Talep Et
              </button>
            </div>

            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <div className="w-6 h-6 flex flex-col justify-center items-center">
                <span className={`bg-orange-600 block transition-all duration-300 ease-out h-0.5 w-6 rounded-sm ${isMenuOpen ? 'rotate-45 translate-y-1' : '-translate-y-0.5'}`}></span>
                <span className={`bg-orange-600 block transition-all duration-300 ease-out h-0.5 w-6 rounded-sm my-0.5 ${isMenuOpen ? 'opacity-0' : 'opacity-100'}`}></span>
                <span className={`bg-orange-600 block transition-all duration-300 ease-out h-0.5 w-6 rounded-sm ${isMenuOpen ? '-rotate-45 -translate-y-1' : 'translate-y-0.5'}`}></span>
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white/95 backdrop-blur-lg border-t border-orange-200">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button onClick={() => scrollToSection('features')} className="block px-3 py-2 text-base font-medium hover:text-orange-600 transition-colors">
                Özellikler
              </button>
              <button onClick={() => scrollToSection('advantages')} className="block px-3 py-2 text-base font-medium hover:text-orange-600 transition-colors">
                Avantajlar
              </button>
              <button onClick={() => scrollToSection('packages')} className="block px-3 py-2 text-base font-medium hover:text-orange-600 transition-colors">
                Paketler
              </button>
              <button onClick={() => scrollToSection('references')} className="block px-3 py-2 text-base font-medium hover:text-orange-600 transition-colors">
                Referanslar
              </button>
              <button onClick={() => scrollToSection('contact')} className="block px-3 py-2 text-base font-medium bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-lg">
                Demo Talep Et
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-100/50 via-amber-100/30 to-red-100/50"></div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-gradient-to-r from-orange-400/20 to-red-400/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-32 h-32 bg-gradient-to-r from-yellow-400/20 to-orange-400/20 rounded-full blur-2xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-1/4 w-24 h-24 bg-gradient-to-r from-red-400/20 to-pink-400/20 rounded-full blur-xl animate-pulse delay-2000"></div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div 
            className={`grid lg:grid-cols-2 gap-12 items-center transition-all duration-1000 ${
              visibleElements.has('hero') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="hero"
          >
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-orange-600 animate-bounce">
                  <Flame className="h-6 w-6" />
                  <span className="text-sm font-semibold uppercase tracking-wider">Restoran Yönetiminde Yeni Dönem</span>
                </div>
                <h1 className="text-4xl md:text-6xl font-bold leading-tight">
                  <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent animate-pulse">
                    Blaze
                  </span>{' '}
                  ile Restoran Yönetiminde Yeni Bir Dönem Başlıyor!
                </h1>
                <p className="text-xl text-slate-600 leading-relaxed">
                  Hızlı, esnek ve güçlü otomasyon altyapısı ile tüm sipariş ve masa yönetimini tek ekrandan yönetin. 
                  Küçük kafelerden büyük restoran zincirlerine kadar her ölçekte çözüm.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:from-orange-600 hover:via-red-600 hover:to-pink-600 transition-all transform hover:scale-105 flex items-center justify-center space-x-2 shadow-xl animate-pulse"
                >
                  <span>Demo Talep Et</span>
                  <Flame className="h-5 w-5" />
                </button>
                <button className="border-2 border-orange-300 text-orange-700 px-8 py-4 rounded-full text-lg font-semibold hover:bg-orange-50 transition-all flex items-center justify-center space-x-2 hover:scale-105 transform">
                  <Play className="h-5 w-5" />
                  <span>Canlı Demo İzle</span>
                </button>
              </div>

              <div className="grid grid-cols-3 gap-8 pt-8 border-t border-orange-200">
                <div className="text-center transform hover:scale-110 transition-transform">
                  <div className="text-2xl font-bold text-orange-600 animate-pulse">500+</div>
                  <div className="text-sm text-slate-500">Aktif İşletme</div>
                </div>
                <div className="text-center transform hover:scale-110 transition-transform">
                  <div className="text-2xl font-bold text-orange-600 animate-pulse delay-500">99.9%</div>
                  <div className="text-sm text-slate-500">Uptime</div>
                </div>
                <div className="text-center transform hover:scale-110 transition-transform">
                  <div className="text-2xl font-bold text-orange-600 animate-pulse delay-1000">24/7</div>
                  <div className="text-sm text-slate-500">Destek</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative z-10 transform hover:scale-105 transition-transform duration-500">
                <img 
                  src="/public/Ekran görüntüsü 2025-07-03 104413.png" 
                  alt="Blaze Restoran Kroki Sistemi" 
                  className="rounded-2xl shadow-2xl border border-orange-200"
                />
              </div>
              <div className="absolute -top-4 -right-4 w-72 h-72 bg-gradient-to-r from-orange-400/20 via-red-400/20 to-pink-400/20 rounded-full blur-3xl animate-pulse"></div>
              <div className="absolute -bottom-4 -left-4 w-72 h-72 bg-gradient-to-r from-amber-400/20 via-orange-400/20 to-red-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-black"></div>
        
        {/* Animated background particles */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-2 h-2 bg-orange-400 rounded-full animate-ping"></div>
          <div className="absolute top-40 right-32 w-1 h-1 bg-red-400 rounded-full animate-pulse delay-1000"></div>
          <div className="absolute bottom-32 left-1/3 w-3 h-3 bg-yellow-400 rounded-full animate-bounce delay-2000"></div>
          <div className="absolute bottom-20 right-20 w-2 h-2 bg-pink-400 rounded-full animate-ping delay-3000"></div>
        </div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div 
            className={`text-center mb-16 transition-all duration-1000 ${
              visibleElements.has('features-title') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="features-title"
          >
            <h2 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-orange-400 via-red-500 to-pink-500 bg-clip-text text-transparent">
                Kapsamlı Özellikler
              </span>
            </h2>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto mb-8">
              İşletmenizi yönetmek için ihtiyacınız olan her şey tek platformda
            </p>
            
            {/* Search and Filter */}
            <div 
              className={`flex flex-col md:flex-row gap-4 justify-center items-center mb-12 transition-all duration-1000 delay-300 ${
                visibleElements.has('features-title') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Özellik ara..."
                  className="pl-12 pr-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:border-orange-500 transition-all w-80"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Filter className="h-5 w-5 text-slate-400" />
                <select 
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white px-4 py-3 focus:outline-none focus:border-orange-500 transition-all"
                >
                  {categories.map(category => (
                    <option key={category} value={category} className="bg-slate-800 text-white">
                      {category}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredFeatures.map((feature, index) => (
              <div 
                key={index}
                className={`group relative bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 hover:border-orange-500/50 transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 ${
                  visibleElements.has(`feature-${index}`) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 50}ms` }}
                data-animate
                id={`feature-${index}`}
              >
                {/* Animated background gradient */}
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 rounded-2xl transition-opacity duration-500`}></div>
                
                {/* Feature Icon */}
                <div className={`relative w-14 h-14 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 shadow-lg`}>
                  <feature.icon className="h-7 w-7 text-white" />
                  
                  {/* Glow effect */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} rounded-xl blur-lg opacity-0 group-hover:opacity-50 transition-opacity duration-500 -z-10`}></div>
                </div>
                
                {/* Feature Content */}
                <div className="relative z-10">
                  <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-orange-300 transition-colors duration-300">
                    {feature.title}
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed group-hover:text-slate-300 transition-colors duration-300">
                    {feature.desc}
                  </p>
                  
                  {/* Category Badge */}
                  <div className="mt-4">
                    <span className={`inline-block px-3 py-1 text-xs font-medium bg-gradient-to-r ${feature.color} text-white rounded-full opacity-80 group-hover:opacity-100 transition-opacity duration-300`}>
                      {feature.category}
                    </span>
                  </div>
                </div>
                
                {/* Hover Arrow */}
                <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-2 group-hover:translate-x-0">
                  <ArrowRight className="h-5 w-5 text-orange-400" />
                </div>
                
                {/* Decorative elements */}
                <div className="absolute bottom-4 left-4 w-2 h-2 bg-orange-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-ping"></div>
                <div className="absolute top-4 left-4 w-1 h-1 bg-red-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 animate-pulse"></div>
              </div>
            ))}
          </div>
          
          {/* Feature Count */}
          <div 
            className={`text-center mt-16 transition-all duration-1000 delay-500 ${
              visibleElements.has('features-count') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="features-count"
          >
            <div className="inline-flex items-center space-x-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl px-8 py-4">
              <Grid3X3 className="h-6 w-6 text-orange-400" />
              <span className="text-white font-semibold">
                Toplam <span className="text-orange-400">{filteredFeatures.length}</span> özellik
              </span>
              {selectedCategory !== 'Tümü' && (
                <span className="text-slate-400">
                  ({selectedCategory} kategorisinde)
                </span>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Advantages Section */}
      <section id="advantages" className="py-20 px-4 sm:px-6 lg:px-8 relative">
        <div className="absolute inset-0 bg-gradient-to-br from-white via-orange-50/30 to-amber-50/50"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div 
            className={`text-center mb-16 transition-all duration-1000 delay-200 ${
              visibleElements.has('advantages-title') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="advantages-title"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent">
                Neden Blaze?
              </span>
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              İşletmenizi bir adım öne taşıyacak avantajları keşfedin
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {advantages.map((advantage, index) => (
              <div 
                key={index}
                className={`bg-white/80 backdrop-blur-sm p-8 rounded-2xl border border-orange-200 hover:border-orange-400 transition-all group shadow-lg hover:shadow-2xl transform hover:scale-105 hover:rotate-1 duration-500 ${
                  visibleElements.has(`advantage-${index}`) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
                data-animate
                id={`advantage-${index}`}
              >
                <div className={`w-16 h-16 bg-gradient-to-r ${advantage.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-12 transition-all duration-500 shadow-lg`}>
                  <advantage.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4 text-slate-800 group-hover:text-orange-600 transition-colors">
                  {advantage.title}
                </h3>
                <p className="text-slate-600 leading-relaxed">{advantage.desc}</p>
                
                {/* Decorative elements */}
                <div className="absolute top-4 right-4 w-2 h-2 bg-orange-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute bottom-4 left-4 w-1 h-1 bg-red-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mobile App Showcase */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div 
            className={`grid lg:grid-cols-2 gap-12 items-center transition-all duration-1000 ${
              visibleElements.has('mobile-showcase') ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
            }`}
            data-animate
            id="mobile-showcase"
          >
            <div className="space-y-6">
              <h3 className="text-3xl font-bold text-slate-800">Mobil Uygulama ile Her Yerde Kontrolde</h3>
              <p className="text-slate-600 leading-relaxed text-lg">
                QR menü sistemi ile müşterileriniz temassız sipariş verebilir. Mobil uygulamanız sayesinde 
                işletmenizi dilediğiniz yerden yönetebilirsiniz.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 transform hover:translate-x-2 transition-transform">
                  <QrCode className="h-6 w-6 text-orange-600" />
                  <span className="text-slate-700">QR kod ile temassız menü</span>
                </div>
                <div className="flex items-center space-x-3 transform hover:translate-x-2 transition-transform">
                  <Smartphone className="h-6 w-6 text-orange-600" />
                  <span className="text-slate-700">Mobil sipariş yönetimi</span>
                </div>
                <div className="flex items-center space-x-3 transform hover:translate-x-2 transition-transform">
                  <Users className="h-6 w-6 text-orange-600" />
                  <span className="text-slate-700">Müşteri profil yönetimi</span>
                </div>
              </div>
            </div>
            <div className="flex justify-center space-x-4">
              <img 
                src="/public/unnamed (3).webp" 
                alt="Blaze Mobil Ana Sayfa" 
                className="w-64 rounded-3xl shadow-2xl border border-orange-200 transform hover:scale-105 hover:rotate-2 transition-all duration-500"
              />
              <img 
                src="/public/unnamed (2).webp" 
                alt="Blaze QR Menü" 
                className="w-64 rounded-3xl shadow-2xl border border-orange-200 mt-8 transform hover:scale-105 hover:-rotate-2 transition-all duration-500"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section id="packages" className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-amber-50 via-orange-50 to-red-50 relative overflow-hidden">
        {/* Background decorations */}
        <div className="absolute top-10 left-10 w-32 h-32 bg-gradient-to-r from-orange-400/10 to-red-400/10 rounded-full blur-2xl animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-gradient-to-r from-pink-400/10 to-purple-400/10 rounded-full blur-2xl animate-pulse delay-1000"></div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div 
            className={`text-center mb-16 transition-all duration-1000 ${
              visibleElements.has('packages-title') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="packages-title"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Size Uygun <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent">Paketi</span> Seçin
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              İşletmenizin büyüklüğüne ve ihtiyaçlarına göre tasarlanmış esnek paket seçenekleri
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {packages.map((pkg, index) => (
              <div 
                key={pkg.id} 
                className={`relative bg-white/90 backdrop-blur-sm rounded-3xl border-2 ${
                  pkg.popular ? 'border-orange-500 shadow-2xl scale-105' : 'border-orange-200 shadow-lg'
                } p-8 hover:transform hover:scale-110 transition-all duration-500 group overflow-hidden ${
                  visibleElements.has(`package-${index}`) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 200}ms` }}
                data-animate
                id={`package-${index}`}
              >
                {/* Animated background gradient */}
                <div className={`absolute inset-0 bg-gradient-to-br ${pkg.color} opacity-5 group-hover:opacity-10 transition-opacity duration-500`}></div>
                
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 animate-bounce">
                    <span className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 text-white px-6 py-2 rounded-full text-sm font-semibold shadow-lg">
                      ⭐ En Popüler
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-8 relative z-10">
                  <div className={`w-20 h-20 bg-gradient-to-r ${pkg.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 group-hover:rotate-12 transition-all duration-500 shadow-lg`}>
                    <pkg.icon className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold mb-4 text-slate-800 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-orange-600 group-hover:to-red-600 group-hover:bg-clip-text transition-all duration-500">
                    {pkg.name}
                  </h3>
                  <div className={`w-full h-2 bg-gradient-to-r ${pkg.color} rounded-full group-hover:h-3 transition-all duration-300`}></div>
                </div>

                <ul className="space-y-4 mb-8 relative z-10">
                  {pkg.features.map((feature, featureIndex) => (
                    <li 
                      key={featureIndex} 
                      className="flex items-center space-x-3 transform hover:translate-x-2 transition-transform duration-300"
                      style={{ transitionDelay: `${featureIndex * 100}ms` }}
                    >
                      <div className="w-6 h-6 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                        <CheckCircle className="h-4 w-4 text-white" />
                      </div>
                      <span className="text-slate-600 group-hover:text-slate-800 transition-colors">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button 
                  onClick={() => scrollToSection('contact')}
                  className={`w-full py-4 rounded-2xl font-semibold transition-all duration-500 transform hover:scale-105 relative overflow-hidden group/btn ${
                    pkg.popular 
                      ? 'bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 hover:from-orange-600 hover:via-red-600 hover:to-pink-600 text-white shadow-lg' 
                      : 'border-2 border-orange-300 hover:bg-gradient-to-r hover:from-orange-500 hover:to-red-500 hover:text-white hover:border-transparent text-orange-700'
                  }`}
                >
                  <span className="relative z-10">Fiyat Alın</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover/btn:opacity-100 transition-opacity duration-500"></div>
                </button>

                {/* Decorative elements */}
                <div className="absolute top-4 right-4 w-3 h-3 bg-orange-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-ping"></div>
                <div className="absolute bottom-4 left-4 w-2 h-2 bg-red-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 animate-pulse"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* References Section */}
      <section id="references" className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div 
            className={`text-center mb-16 transition-all duration-1000 ${
              visibleElements.has('references-title') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="references-title"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent">Blaze</span> Kullanan İşletmeler
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Türkiye genelinde yüzlerce işletmede aktif olarak kullanılmaktadır
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index} 
                className={`bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 p-6 rounded-xl border border-orange-200 shadow-lg hover:shadow-2xl transform hover:scale-105 hover:rotate-1 transition-all duration-500 ${
                  visibleElements.has(`testimonial-${index}`) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 200}ms` }}
                data-animate
                id={`testimonial-${index}`}
              >
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-500 fill-current animate-pulse" style={{ animationDelay: `${i * 200}ms` }} />
                  ))}
                </div>
                <p className="text-slate-600 mb-4 italic">"{testimonial.text}"</p>
                <div>
                  <div className="font-semibold text-slate-800">{testimonial.name}</div>
                  <div className="text-sm text-slate-500">{testimonial.business}</div>
                </div>
              </div>
            ))}
          </div>

          <div 
            className={`text-center transition-all duration-1000 ${
              visibleElements.has('references-stats') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="references-stats"
          >
            <div className="inline-flex items-center space-x-2 text-slate-500 mb-4">
              <Users className="h-5 w-5" />
              <span>500+ Aktif İşletme</span>
            </div>
            <p className="text-slate-600">
              Güvenilir yapısı ve kullanıcı dostu arayüzü sayesinde restoranlar, kafeler, 
              pastaneler ve fast food zincirleri tarafından tercih edilmektedir.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
        <div className="max-w-4xl mx-auto">
          <div 
            className={`text-center mb-16 transition-all duration-1000 ${
              visibleElements.has('faq-title') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="faq-title"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Sıkça Sorulan <span className="bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent">Sorular</span>
            </h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <details 
                key={index} 
                className={`bg-white/80 backdrop-blur-sm rounded-xl border border-orange-200 p-6 group shadow-lg hover:shadow-xl transition-all duration-500 hover:scale-102 ${
                  visibleElements.has(`faq-${index}`) ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
                data-animate
                id={`faq-${index}`}
              >
                <summary className="flex justify-between items-center cursor-pointer font-semibold text-slate-800 hover:text-orange-600 transition-colors">
                  <span>{faq.q}</span>
                  <ChevronDown className="h-5 w-5 text-slate-500 group-open:rotate-180 group-open:text-orange-600 transition-all duration-300" />
                </summary>
                <p className="mt-4 text-slate-600 leading-relaxed">{faq.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-4xl mx-auto">
          <div 
            className={`text-center mb-16 transition-all duration-1000 ${
              visibleElements.has('contact-title') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="contact-title"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-slate-800">
              Bizimle İletişime Geçin
            </h2>
            <p className="text-xl text-slate-600">
              Size özel teklif alın - Aynı gün içinde sizinle iletişime geçiyoruz!
            </p>
          </div>

          <div 
            className={`grid md:grid-cols-2 gap-12 transition-all duration-1000 ${
              visibleElements.has('contact-content') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
            data-animate
            id="contact-content"
          >
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold mb-6 text-slate-800">İletişim Bilgileri</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4 transform hover:translate-x-2 transition-transform">
                    <div className="w-12 h-12 bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 rounded-xl flex items-center justify-center">
                      <Phone className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-slate-800">Telefon</div>
                      <div className="text-slate-500">0850 XXX XX XX</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4 transform hover:translate-x-2 transition-transform">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 rounded-xl flex items-center justify-center">
                      <MessageCircle className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-slate-800">WhatsApp</div>
                      <div className="text-slate-500">0850 XXX XX XX</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4 transform hover:translate-x-2 transition-transform">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 via-cyan-500 to-sky-500 rounded-xl flex items-center justify-center">
                      <Mail className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-slate-800">E-posta</div>
                      <div className="text-slate-500">info@blaze.com.tr</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 p-6 rounded-xl border border-orange-200 transform hover:scale-105 transition-transform">
                <h4 className="font-semibold mb-4 text-slate-800">Hızlı Destek</h4>
                <p className="text-slate-600 text-sm mb-4">
                  Uzman ekibimiz size en uygun paketi sunmak için hazır. 
                  Telefon, WhatsApp ve uzaktan bağlantı ile destek sağlıyoruz.
                </p>
                <div className="flex items-center space-x-2 text-orange-600">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm">Aynı gün içinde geri dönüş</span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 p-8 rounded-2xl border border-orange-200 shadow-lg transform hover:scale-105 transition-transform">
              <h3 className="text-xl font-bold mb-6 text-slate-800">Teklif Formu</h3>
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2 text-slate-700">Ad Soyad *</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 bg-white border border-orange-200 rounded-xl focus:border-orange-500 focus:outline-none transition-colors hover:border-orange-300"
                    placeholder="Adınız ve soyadınız"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2 text-slate-700">İşletme Adı *</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 bg-white border border-orange-200 rounded-xl focus:border-orange-500 focus:outline-none transition-colors hover:border-orange-300"
                    placeholder="İşletmenizin adı"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2 text-slate-700">Telefon *</label>
                  <input 
                    type="tel" 
                    className="w-full px-4 py-3 bg-white border border-orange-200 rounded-xl focus:border-orange-500 focus:outline-none transition-colors hover:border-orange-300"
                    placeholder="0XXX XXX XX XX"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2 text-slate-700">E-posta</label>
                  <input 
                    type="email" 
                    className="w-full px-4 py-3 bg-white border border-orange-200 rounded-xl focus:border-orange-500 focus:outline-none transition-colors hover:border-orange-300"
                    placeholder="ornek@email.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2 text-slate-700">İlgilendiğiniz Paket</label>
                  <select className="w-full px-4 py-3 bg-white border border-orange-200 rounded-xl focus:border-orange-500 focus:outline-none transition-colors hover:border-orange-300">
                    <option>Lite Paket</option>
                    <option>Prime Paket</option>
                    <option>Master Paket</option>
                    <option>Henüz karar vermedim</option>
                  </select>
                </div>
                <button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 text-white py-3 rounded-xl font-semibold hover:from-orange-600 hover:via-red-600 hover:to-pink-600 transition-all flex items-center justify-center space-x-2 shadow-lg transform hover:scale-105"
                >
                  <span>Teklif Al</span>
                  <ArrowRight className="h-5 w-5" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-slate-800 via-slate-900 to-black py-12 px-4 sm:px-6 lg:px-8 border-t border-orange-200 relative overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-10 left-10 w-20 h-20 bg-gradient-to-r from-orange-500/10 to-red-500/10 rounded-full blur-xl animate-pulse"></div>
          <div className="absolute bottom-10 right-10 w-32 h-32 bg-gradient-to-r from-pink-500/10 to-purple-500/10 rounded-full blur-2xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Flame className="h-8 w-8 text-orange-500 animate-pulse" />
                <span className="text-2xl font-bold bg-gradient-to-r from-orange-400 via-red-500 to-pink-500 bg-clip-text text-transparent">
                  Blaze
                </span>
              </div>
              <p className="text-slate-400">
                Restoran yönetiminde yeni dönemin öncüsü. Hızlı, güvenilir ve kullanıcı dostu çözümler.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 text-white">Ürün</h4>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Özellikler</a></li>
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Paketler</a></li>
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Demo</a></li>
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Güncellemeler</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 text-white">Destek</h4>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Yardım Merkezi</a></li>
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Eğitim Videoları</a></li>
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Teknik Destek</a></li>
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">SSS</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 text-white">Şirket</h4>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Hakkımızda</a></li>
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">İletişim</a></li>
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Gizlilik</a></li>
                <li><a href="#" className="hover:text-orange-400 transition-colors transform hover:translate-x-1 inline-block">Şartlar</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-700 mt-12 pt-8 text-center text-slate-400">
            <p>&copy; 2025 Blaze Restoran Yönetim Sistemi. Tüm hakları saklıdır.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;